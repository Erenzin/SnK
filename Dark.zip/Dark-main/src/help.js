const help = (prefix) => {
	return `


╭━⋆⃟⊱๑⋆⃟⊱๑ˌ⋆⃟⊱๑⋆⃟⊱๑⋆⃟⊱━╮
   🌹𝐉𝐔𝐍𝐈𝐍 𝐁𝐎𝐓🌹 
╰━⋆⃟⊱๑⋆⃟⊱๑ˌ⋆⃟⊱๑⋆⃟⊱๑⋆⃟⊱━╯


〲╭─────⊣〘 𝗙𝗜𝗚𝗨𝗥𝗜𝗡𝗛𝗔 〙
〲│
〲┴┬➣ COMANDO: !sticker
〲┴┬➣ DESC: Converter em figurinha
〲┴┬➣ USO: Converter em figurinha
〲
〲┴┬➣ COMANDO: !sticker nobg
〲┴┬➣ DESC: Imagem em figurinha sem fundo
〲┴┬➣ USO: Enviar imagem com legenda
〲
〲┴┬➣ COMANDO: !toimg
〲┴┬➣ DESC: Converter figurinha em imagem
〲┴┬➣ USO: Figurinha de resposta
〲
〲┴┬➣ COMANDO: !tsticker
〲┴┬➣ DESC: Converter texto em Figurinha
〲┴┬➣ USO: !tsticker [seu texto]
〲
〲︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶
〲
〲╭─────⊣〘 𝗠𝗘𝗠𝗘 〙
〲│
〲┴┬➣ COMANDO: !meme
〲┴┬➣ DESC: Imagens aleatórias de meme
〲┴┬➣ USO: Apenas envie o comando
〲
〲┴┬➣ COMANDO: !memeindo
〲┴┬➣ DESC: Imagens aleatórias de meme
〲┴┬➣ USO: Apenas envie o comando
〲
〲︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶
〲
〲╭─────⊣〘 𝗢𝗨𝗧𝗥𝗢𝗦 〙 
〲│
〲┴┬➣ COMANDO: !gtts
〲┴┬➣ DESC: Fazer o bot gravar áudio
〲┴┬➣ USO: !gtts [cc] [text]
〲┴┬➣ EXEMPLO: !gtts ja On2-chan
〲
〲┴┬➣ COMANDO: !loli
〲┴┬➣ DESC: Imagens de loli
〲┴┬➣ USO: Apenas envie o comando
〲
〲┴┬➣ COMANDO: !nsfwloli
〲┴┬➣ DESC: Imagens de nsfw loli
〲┴┬➣ USO: Apenas envie o comando
〲
〲┴┬➣ COMANDO: !url2img
〲┴┬➣ DESC: Tirar screenshots da web
〲┴┬➣ USO: !url2img [tipe] [url]
〲
〲┴┬➣ COMANDO: !simi
〲┴┬➣ DESC: Sua mensagem será respondida
〲┴┬➣ USO: !simi [sua mensagem]
〲
〲┴┬➣ COMANDO: !ocr
〲┴┬➣ DESC: Pegue o texto na foto
〲┴┬➣ USO: Enviar imagem com legenda
〲
〲┴┬➣ COMANDO: !wait
〲┴┬➣ DESC: Procure anime [Que anime é]
〲┴┬➣ USO: Enviar imagem com legenda
〲
〲┴┬➣ COMANDO: !clone
〲┴┬➣ DESC: Usar foto de perfil da pessoa
〲┴┬➣ USO: !clone @member
〲┴┬➣ NOTA: Usado por adms
〲
〲┴┬➣ COMANDO: !listaadmins
〲┴┬➣ DESC: Marca todos os adms do grupo
〲┴┬➣ USO: !listaadmins
〲┴┬➣ NOTA: Usado por membros do grupo
〲
〲┴┬➣ COMANDO: !nulis
〲┴┬➣ DESC: Foto com seu texto no caderno
〲┴┬➣ USO: !nulis [texto]
〲┴┬➣ NOTA: Usado em grupos
〲
〲┴┬➣ COMANDO: !tiktokstalk
〲┴┬➣ DESC: Mostra o perfil do usuário
〲┴┬➣ USO: !tiktokstalk @user
〲┴┬➣ NOTA: Usado em grupos
〲
〲┴┬➣ COMANDO: !tiktok
〲┴┬➣ DESC: Baixar um video do tik tok
〲┴┬➣ USO: !tiktok [link]
〲┴┬➣ NOTA: Usado em grupos
〲
〲┴┬➣ COMANDO: !ytsearch
〲┴┬➣ DESC: Info de um video no YouTube
〲┴┬➣ USO: !ytsearch [pesquisa]
〲┴┬➣ NOTA: Usado em grupos
〲
〲┴┬➣ COMANDO: !yt2mp3
〲┴┬➣ DESC: Baixar uma Música do YouTube
〲┴┬➣ USO: !yt2mp3 [link]
〲┴┬➣ NOTA: Usado em grupos
〲
〲┴┬➣ COMANDO: !hilih
〲┴┬➣ USO: !hilih [texto]
〲┴┬➣ NOTA: Apenas envie o comando
〲
〲┴┬➣ COMANDO: !blocklist
〲┴┬➣ DESC Lista de ctts bloqueados
〲┴┬➣ USO: !blocklist
〲┴┬➣ NOTA: Usado em grupos
〲
〲︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶
〲
〲╭─────⊣〘 𝗚𝗥𝗨𝗣𝗢 〙
〲│
〲┴┬➣ COMANDO: !add
〲┴┬➣ DESC: Adicionar membro ao grupo
〲┴┬➣ USO: !add 55xxxxxxxx
〲┴┬➣ NOTA: Usado quando o bot é admin!
〲
〲┴┬➣ COMANDO: !ban
〲┴┬➣ DESC: Banir membros do grupo
〲┴┬➣ USO: !ban @member
〲┴┬➣ NOTA: Usado quando o bot é admin!
〲
〲┴┬➣ COMANDO: !adm
〲┴┬➣ DESC: Torna um membro como adm 
〲┴┬➣ USO: !adm @member
〲┴┬➣ NOTA: Usado quando o bot é admin!
〲
〲┴┬➣ COMANDO: !rebaixar
〲┴┬➣ DESC: Tornar o um adm como membro
〲┴┬➣ USO: !rebaixar @member
〲┴┬➣ NOTA: Usado quando o bot é admin!
〲
〲┴┬➣ COMANDO: !linkgrupo
〲┴┬➣ DESC: Enviar o link do grupo
〲┴┬➣ USO: Apenas envie o comando
〲┴┬➣ NOTA: Usado quando o bot é admin!
〲
〲┴┬➣ COMANDO: !mencionar
〲┴┬➣ DESC: Marca todos do grupo
〲┴┬➣ USO: Apenas envie o comando
〲┴┬➣ NOTA: Usado por adms do grupo!
〲
〲┴┬➣ COMANDO: !simih
〲┴┬➣ DESC: Ative o modo simi no grupo
〲┴┬➣ ATIVAR: !simih 1 
〲┴┬➣ DESATIVAR: !simih 0
〲┴┬➣ NOTA: Usado quando você é adm
〲
〲┴┬➣ COMANDO: !bemvindo
〲┴┬➣ DESC: Ative o recurso de boas vindas
〲┴┬➣ ATIVAR: !bemvindo 1 
〲┴┬➣ DESATIVAR: !bemvindo 0
〲┴┬➣ NOTA: Usado quando o bot é adm!
〲
〲︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶
〲╭────⊣〘 𝗢𝗪𝗡𝗘𝗥 𝗕𝗢𝗧 〙
〲│
〲┴┬➣ COMANDO: !att
〲┴┬➣ DESC: Envia uma msg para todos
〲┴┬➣ USO: !att [texto]
〲┴┬➣ NOTA: Usado pelo proprietário do bot!
〲
〲┴┬➣ COMANDO: !prefix
〲┴┬➣ DESC: Substituir prefixo
〲┴┬➣ USO: !prefix [ ! ]
〲┴┬➣ NOTA: Usado pelo proprietário do bot!
〲
〲︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶
〲╭────⊣〘 𝗦𝗨𝗣𝗢𝗥𝗧𝗘 〙
〲│
〲┴┬➣ Wpp: wa.me/556696770734
〲┴┬➣ Wpp: wa.me/553196891466
〲︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶
〲 
〲 ║▌│█║▌│ █║▌│█│║▌║
〲 ║▌│█║▌│ █║▌│█│║▌║
〲
〲 Copyright © 𝐉𝐔𝐍𝐈𝐍 𝐁𝐎𝐓 2020 
〲
︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶︶`
}

exports.help = help











